%% 古代玻璃成分分析与鉴别 —— 数据预处理
% 2022 CUMCM C题
% 功能：读取附件.xlsx三张表单，进行数据清洗、编码、CLR变换
% 可独立运行：preprocess
%
% 输出：
%   cleaned_data.csv   —— 预处理后数据
%   预处理对比图（成分分布箱线图）

%% 初始化
clc;
fprintf('数据预处理...\n');

% 路径
base_dir = fileparts(mfilename('fullpath'));
result_dir = fullfile(base_dir, '..', 'result');
fig_dir = fullfile(result_dir, 'figures');
if ~exist(result_dir, 'dir'), mkdir(result_dir); end
if ~exist(fig_dir, 'dir'), mkdir(fig_dir); end

% 附件路径
attach_path = fullfile(base_dir, '..', '..', 'cumcm2022c', '附件.xlsx');
if ~exist(attach_path, 'file')
    % 备选路径
    attach_path = fullfile(base_dir, '..', '..', '2022C参考', '附件.xlsx');
end
fprintf('数据源: %s\n', attach_path);

%% 一、读取原始数据 %%
fprintf('\n-- 一、读取原始数据 ---\n');

% 表单1：文物表面信息
opts1 = spreadsheetImportOptions('NumVariables', 4);
opts1.Sheet = 1;
opts1.DataRange = 'B2:E59';
opts1.VariableNames = {'ORNA', 'TYPE', 'COLOR', 'WEAT'};
opts1.VariableTypes = {'string', 'string', 'string', 'string'};
opts1 = setvaropts(opts1, {'ORNA', 'TYPE', 'COLOR', 'WEAT'}, 'EmptyFieldRule', 'auto');
T1 = readtable(attach_path, opts1, 'UseExcel', false);
fprintf('表单1 读取完成: %d 行, 文物表面信息\n', height(T1));

% 表单2：化学成分数据（69个采样点）
opts2 = spreadsheetImportOptions('NumVariables', 15);
opts2.Sheet = 2;
opts2.DataRange = 'A2:O70';
opts2.VariableNames = {'SAMPLE_ID', 'SiO2', 'Na2O', 'K2O', 'CaO', 'MgO', ...
    'Al2O3', 'Fe2O3', 'CuO', 'PbO', 'BaO', 'P2O5', 'SrO', 'SnO2', 'SO2'};
opts2.VariableTypes = {'string', 'double', 'double', 'double', 'double', 'double', ...
    'double', 'double', 'double', 'double', 'double', 'double', 'double', 'double', 'double'};
opts2 = setvaropts(opts2, {'SiO2', 'Na2O', 'K2O', 'CaO', 'MgO', ...
    'Al2O3', 'Fe2O3', 'CuO', 'PbO', 'BaO', 'P2O5', 'SrO', 'SnO2', 'SO2'}, 'FillValue', 0);
T2_raw = readtable(attach_path, opts2, 'UseExcel', false);
fprintf('表单2 读取完成: %d 行, %d 种化学成分\n', height(T2_raw), width(T2_raw)-1);

% 表单3：待预测样本
opts3 = spreadsheetImportOptions('NumVariables', 16);
opts3.Sheet = 3;
opts3.DataRange = 'A2:P9';
opts3.VariableNames = {'SAMPLE_ID', 'WEAT', 'SiO2', 'Na2O', 'K2O', 'CaO', 'MgO', ...
    'Al2O3', 'Fe2O3', 'CuO', 'PbO', 'BaO', 'P2O5', 'SrO', 'SnO2', 'SO2'};
opts3.VariableTypes = {'string', 'string', 'double', 'double', 'double', 'double', 'double', ...
    'double', 'double', 'double', 'double', 'double', 'double', 'double', 'double', 'double'};
opts3 = setvaropts(opts3, {'SiO2', 'Na2O', 'K2O', 'CaO', 'MgO', ...
    'Al2O3', 'Fe2O3', 'CuO', 'PbO', 'BaO', 'P2O5', 'SrO', 'SnO2', 'SO2'}, 'FillValue', 0);
T3_raw = readtable(attach_path, opts3, 'UseExcel', false);
fprintf('表单3 读取完成: %d 行, 未知样本\n', height(T3_raw));

%% 二、表单1预处理：类别变量编码 %%
fprintf('\n-- 二、表单1预处理 ---\n');

% 创建副本
T1_proc = T1;

% 纹饰编码: A→0, B→1, C→2
T1_proc.ORNA = categorical(cellstr(T1_proc.ORNA));
orna_levels = categories(T1_proc.ORNA);
fprintf('纹饰类别: %s\n', strjoin(orna_levels, ', '));
T1_proc.ORNA_num = double(categorical(cellstr(T1_proc.ORNA))) - 1;

% 类型编码: 高钾→0, 铅钡→1
% 注意: categorical默认按Unicode排序，中文'铅'(U+94C5)<'高'(U+9AD8)，
% 必须显式指定顺序{'高钾','铅钡'}以确保编码正确
T1_proc.TYPE = categorical(cellstr(T1_proc.TYPE), {'高钾', '铅钡'});
type_levels = categories(T1_proc.TYPE);
fprintf('玻璃类型: %s\n', strjoin(type_levels, ', '));
T1_proc.TYPE_num = double(T1_proc.TYPE) - 1;  % 高钾→1-1=0, 铅钡→2-1=1

% 颜色编码
% 先处理缺失值：用众数填充
color_str = cellstr(T1_proc.COLOR);
missing_color = ismissing(T1_proc.COLOR) | strcmp(color_str, '') | strcmp(color_str, 'NaN');
if any(missing_color)
    valid_colors = color_str(~missing_color);
    % 手动计算众数
    [unique_colors, ~, ic] = unique(valid_colors);
    counts = accumarray(ic, 1);
    [~, max_idx] = max(counts);
    mode_color = unique_colors{max_idx};
    color_str(missing_color) = {mode_color};
    T1_proc.COLOR = categorical(color_str);
    fprintf('颜色缺失值: %d 个, 已用众数 "%s" 填充\n', sum(missing_color), mode_color);
end
T1_proc.COLOR_cat = categorical(cellstr(T1_proc.COLOR));
color_levels = categories(T1_proc.COLOR_cat);
fprintf('颜色类别: %s\n', strjoin(color_levels, ', '));
T1_proc.COLOR_num = double(categorical(cellstr(T1_proc.COLOR))) - 1;

% 风化编码: 无风化→0, 风化→1
T1_proc.WEAT = categorical(cellstr(T1_proc.WEAT));
weat_levels = categories(T1_proc.WEAT);
fprintf('风化状态: %s\n', strjoin(weat_levels, ', '));
T1_proc.WEAT_num = double(categorical(cellstr(T1_proc.WEAT))) - 1;

fprintf('表单1编码完成: 纹饰(%d类), 类型(%d类), 颜色(%d类), 风化(%d类)\n', ...
    length(orna_levels), length(type_levels), length(color_levels), length(weat_levels));

%% 三、表单2预处理：成分数据清洗 %%
fprintf('\n-- 三、表单2预处理 ---\n');

% 提取文物编号（去除部位/风化点标记）
sample_ids = cellstr(T2_raw.SAMPLE_ID);
artifact_nums = zeros(length(sample_ids), 1);
for i = 1:length(sample_ids)
    sid = sample_ids{i};
    % 提取开头数字部分
    num_part = regexp(sid, '^\d+', 'match');
    if ~isempty(num_part)
        artifact_nums(i) = str2double(num_part{1});
    else
        artifact_nums(i) = NaN;
    end
end

% 成分矩阵（14种氧化物）
comp_names = {'SiO2', 'Na2O', 'K2O', 'CaO', 'MgO', 'Al2O3', ...
    'Fe2O3', 'CuO', 'PbO', 'BaO', 'P2O5', 'SrO', 'SnO2', 'SO2'};
X2_raw = T2_raw{:, 2:15};

% 零值处理：乘法替换法（Multiplicative Replacement）
% 对于包含c个零值的D维组成，将每个零值替换为δ，并等比例压缩非零组分
% 该策略保持非零组分间的比率关系（ratio structure），是成分数据分析的标准方法
delta_zero = 0.01;  % 替换值 = 0.01%（与检测精度0.1%相差一个数量级）
n_zeros = sum(X2_raw(:) == 0);
fprintf('零值处理: 共%d个零值，采用乘法替换法(delta=%.2f%%)\n', n_zeros, delta_zero);
for i_row = 1:size(X2_raw, 1)
    row = X2_raw(i_row, :);
    zero_mask = (row == 0);
    if any(zero_mask)
        c = sum(zero_mask);
        sum_pos = sum(row(~zero_mask));
        if sum_pos > 0
            scale = 1 - c * delta_zero / sum_pos;
            row(~zero_mask) = row(~zero_mask) * scale;
        end
        row(zero_mask) = delta_zero;
        X2_raw(i_row, :) = row;
    end
end
fprintf('  替换前后成分总和保持一致\n');

% 无效数据标注：成分总和超出[85, 105]范围的采样点
comp_sums_raw = sum(X2_raw, 2);
invalid_mask = (comp_sums_raw < 85) | (comp_sums_raw > 105);
fprintf('成分总和范围检查: [%.2f, %.2f]%%\n', min(comp_sums_raw), max(comp_sums_raw));
if any(invalid_mask)
    fprintf('  警告: %d 个采样点总和超出[85,105]范围\n', sum(invalid_mask));
end

% 归一化：使每个样本总和为100%
X2_norm = 100 * X2_raw ./ sum(X2_raw, 2);

% 中心对数比(CLR)变换：打破成分数据的定和约束
% z_i = log(x_i / g(x)), 其中g(x)是几何均值
X2_clr = zeros(size(X2_norm));
for i = 1:size(X2_norm, 1)
    row = X2_norm(i, :);
    gm = geomean(row(row > 0));  % 几何均值（排除零值）
    X2_clr(i, :) = log(row ./ gm);
end

% 缺失值处理：NaN用对应列的均值填充
nan_count = sum(isnan(X2_clr(:)));
if nan_count > 0
    col_means = mean(X2_clr, 1, 'omitnan');
    for j = 1:size(X2_clr, 2)
        col_nan = isnan(X2_clr(:, j));
        if any(col_nan)
            X2_clr(col_nan, j) = col_means(j);
        end
    end
    fprintf('缺失值填充: %d 个NaN → 列均值(CLR空间)\n', nan_count);
end

% 关联表单1的类型和风化信息
T2_proc = table(artifact_nums, sample_ids);
T2_proc.ARTIFACT_NUM = artifact_nums;
T2_proc.SAMPLE_ID = string(sample_ids);

% 匹配类型和风化
T2_proc.TYPE = repmat("", height(T2_proc), 1);
T2_proc.TYPE_num = zeros(height(T2_proc), 1);
T2_proc.WEAT = repmat("", height(T2_proc), 1);
T2_proc.WEAT_num = zeros(height(T2_proc), 1);

for i = 1:height(T2_proc)
    an = T2_proc.ARTIFACT_NUM(i);
    match_row = find((1:height(T1_proc))' == an, 1);
    if ~isempty(match_row)
        T2_proc.TYPE(i) = string(T1_proc.TYPE(match_row));
        T2_proc.TYPE_num(i) = T1_proc.TYPE_num(match_row);
        T2_proc.WEAT(i) = string(T1_proc.WEAT(match_row));
        T2_proc.WEAT_num(i) = T1_proc.WEAT_num(match_row);
    end
end

% 检查匹配情况
unmatched = T2_proc.TYPE == "" | ismissing(T2_proc.TYPE);
fprintf('表单1-2匹配: %d/%d 匹配成功 (%d未匹配)\n', ...
    sum(~unmatched), height(T2_proc), sum(unmatched));

% 合并CLR变换后的成分数据
X2_table = array2table(X2_clr, 'VariableNames', comp_names);
X2_norm_table = array2table(X2_norm, 'VariableNames', comp_names);
T2_merged = [T2_proc, X2_table];

fprintf('表单2预处理完成: %d采样点, CLR变换后有NaN=%d\n', ...
    height(T2_merged), sum(isnan(table2array(X2_table)), 'all'));

%% 四、表单3预处理 %%
fprintf('\n-- 四、表单3预处理 ---\n');

% 成分矩阵
X3_raw = T3_raw{:, 3:16};

% 零值处理：乘法替换法（与表单2一致）
for i_row = 1:size(X3_raw, 1)
    row = X3_raw(i_row, :);
    zero_mask = (row == 0);
    if any(zero_mask)
        c = sum(zero_mask);
        sum_pos = sum(row(~zero_mask));
        if sum_pos > 0
            scale = 1 - c * delta_zero / sum_pos;
            row(~zero_mask) = row(~zero_mask) * scale;
        end
        row(zero_mask) = delta_zero;
        X3_raw(i_row, :) = row;
    end
end
fprintf('表单3零值处理完成（乘法替换法, delta=%.2f%%）\n', delta_zero);

% 风化编码
T3_proc = T3_raw;
weat3_str = cellstr(T3_proc.WEAT);
T3_proc.WEAT_num = zeros(length(weat3_str), 1);
for i = 1:length(weat3_str)
    if contains(weat3_str{i}, '风化') && ~contains(weat3_str{i}, '无')
        T3_proc.WEAT_num(i) = 1;
    end
end

% 归一化 → CLR变换
X3_norm = 100 * X3_raw ./ sum(X3_raw, 2);
X3_clr = zeros(size(X3_norm));
for i = 1:size(X3_norm, 1)
    row = X3_norm(i, :);
    gm = geomean(row(row > 0));
    X3_clr(i, :) = log(row ./ gm);
end

% NaN填充
if any(isnan(X3_clr(:)))
    col_means3 = mean(X3_clr, 1, 'omitnan');
    for j = 1:size(X3_clr, 2)
        col_nan = isnan(X3_clr(:, j));
        if any(col_nan)
            X3_clr(col_nan, j) = col_means3(j);
        end
    end
end

fprintf('表单3预处理完成: %d 个未知样本\n', height(T3_proc));

%% 五、绘图：预处理对比 %%
fprintf('\n-- 五、生成预处理对比图 ---\n');

% 图1：主要成分含量箱线图（高钾 vs 铅钡，选4种关键成分）
figure('Position', [100, 100, 1600, 600]);
high_k_idx = T2_proc.TYPE_num == 0;
pb_idx = T2_proc.TYPE_num == 1;

% 选取关键成分：SiO2(1), K2O(3), PbO(9), BaO(10)
key_comp_idx = [1, 3, 9, 10];  % SiO2, K2O, PbO, BaO
key_comp_names = comp_names(key_comp_idx);

for p = 1:4
    subplot(1, 4, p);
    j = key_comp_idx(p);
    boxplot([X2_norm(high_k_idx, j); X2_norm(pb_idx, j)], ...
        [repmat({'高钾'}, sum(high_k_idx), 1); repmat({'铅钡'}, sum(pb_idx), 1)]);
    title(key_comp_names{p}, 'FontSize', 12, 'FontWeight', 'bold');
    ylabel('归一化含量 (%)');
    grid on;
end
sgtitle('关键成分分布对比', 'FontSize', 14, 'FontWeight', 'bold');
print(gcf, fullfile(fig_dir, 'preprocess_comparison_300.png'), '-dpng', '-r300');
close(gcf);

fprintf('预处理图1-2已保存到 result/figures/\n');

%% 六、保存预处理结果 %%
fprintf('\n-- 六、保存预处理结果 ---\n');

% 保存所有预处理数据的MAT文件（供后续脚本加载）
save(fullfile(result_dir, 'preprocessed_data.mat'), ...
    'T1_proc', 'T2_merged', 'T3_proc', ...
    'X2_clr', 'X2_norm', 'X2_raw', 'X3_clr', 'X3_norm', 'X3_raw', ...
    'comp_names', 'T2_proc');

fprintf('预处理结果已保存:\n');
fprintf('  %s\n', fullfile(result_dir, 'preprocessed_data.mat'));

fprintf('\n%%\n');
fprintf('数据预处理完成!\n');
